/**
 * TEMA 8: ORM CON HIBERNATE (JAVA)
 * Aplicación Web Educativa y Laboratorio Interactivo
 * Tecnólogo ADSO - SENA CIMM Regional Boyacá
 */

document.addEventListener('DOMContentLoaded', () => {

  // ========================================================
  // 1. STATE & DATABASE SIMULATION
  // ========================================================
  const state = {
    challengeActive: false,
    dialect: 'mysql', // 'mysql' | 'h2' | 'postgres'
    formatSql: true,
    showSql: true,
    products: [
      { id: 1, nombre: 'Portátil Lenovo ThinkPad', precio: 3200000, cantidad: 15, categoria: 'Tecnología' },
      { id: 2, nombre: 'Monitor LG 27" 4K IPS', precio: 1150000, cantidad: 8, categoria: 'Periféricos' },
      { id: 3, nombre: 'Teclado Mecánico RGB', precio: 240000, cantidad: 25, categoria: 'Accesorios' }
    ],
    nextId: 4,
    timer: {
      totalSeconds: 20 * 60, // 20 minutes
      currentSeconds: 20 * 60,
      intervalId: null,
      isRunning: false
    }
  };

  // ========================================================
  // 2. DOM ELEMENTS
  // ========================================================
  const terminalBody = document.getElementById('terminalBody');
  const dbTableBody = document.getElementById('dbTableBody');
  const tableHeaderRow = document.getElementById('tableHeaderRow');
  const dbRowCount = document.getElementById('dbRowCount');
  const dialectBadge = document.getElementById('dialectBadge');
  const selectDialect = document.getElementById('selectDialect');
  const chkFormatSql = document.getElementById('chkFormatSql');

  // Action Buttons
  const btnPersist = document.getElementById('btnPersist');
  const btnFindAll = document.getElementById('btnFindAll');
  const btnDirtyChecking = document.getElementById('btnDirtyChecking');
  const btnDelete = document.getElementById('btnDelete');
  const btnClearConsole = document.getElementById('btnClearConsole');
  const btnCopySql = document.getElementById('btnCopySql');

  // Input Fields
  const inputNombre = document.getElementById('inputNombre');
  const inputPrecio = document.getElementById('inputPrecio');
  const inputCantidad = document.getElementById('inputCantidad');
  const inputCategoria = document.getElementById('inputCategoria');
  const groupCategoria = document.getElementById('groupCategoria');

  // Challenge elements
  const btnActivateChallenge = document.getElementById('btnActivateChallenge');
  const btnResetChallenge = document.getElementById('btnResetChallenge');
  const btnChallengeText = document.getElementById('btnChallengeText');
  const retoCodeSnippet = document.getElementById('retoCodeSnippet');
  const diffBadge = document.getElementById('diffBadge');

  // Annotation interactive panel
  const annotTags = document.querySelectorAll('.annot-tag');
  const annotActiveCard = document.getElementById('annotActiveCard');
  const detailsDefaultState = document.querySelector('.details-default-state');
  const annotTitle = document.getElementById('annotTitle');
  const annotDesc = document.getElementById('annotDesc');
  const annotSqlEffect = document.getElementById('annotSqlEffect');
  const annotTip = document.getElementById('annotTip');

  // Timer elements
  const bigTimerDisplay = document.getElementById('bigTimerDisplay');
  const navTimerDisplay = document.getElementById('navTimerDisplay');
  const currentPhasePill = document.getElementById('currentPhasePill');
  const btnStartTimer = document.getElementById('btnStartTimer');
  const btnPauseTimer = document.getElementById('btnPauseTimer');
  const btnResetTimer = document.getElementById('btnResetTimer');
  const btnTimerToggle = document.getElementById('btnTimerToggle');

  // Code project viewer
  const fileTabs = document.querySelectorAll('.file-tab');
  const activeFilePath = document.getElementById('activeFilePath');
  const fileViewerCode = document.getElementById('fileViewerCode');
  const btnCopyFileContent = document.getElementById('btnCopyFileContent');

  // Code Comparison tabs
  const compTabs = document.querySelectorAll('.comp-tab');
  const codeJdbc = document.getElementById('codeJdbc');
  const codeOrm = document.getElementById('codeOrm');

  // ========================================================
  // 3. ANNOTATIONS DICTIONARY DATA
  // ========================================================
  const annotationsData = {
    'entity': {
      title: '@Entity',
      desc: 'Marca la clase Java como una entidad persistente gestionada por JPA y Hibernate. Le indica al ORM que cada instancia de esta clase representará una fila en la base de datos.',
      sql: 'CREATE TABLE productos (...);',
      tip: 'Toda entidad JPA requiere obligatoriamente una clave primaria (@Id) y un constructor vacío sin argumentos (public o protected).'
    },
    'table': {
      title: '@Table(name = "productos")',
      desc: 'Especifica el nombre exacto de la tabla en el motor de base de datos relacional. Si se omite, Hibernate asume el nombre de la clase en minúsculas (por defecto "producto").',
      sql: 'TABLE "productos"',
      tip: 'Úsalo para evitar conflictos con palabras reservadas de SQL (como "User" o "Order") o respetar convenciones plurales de tu empresa.'
    },
    'id': {
      title: '@Id',
      desc: 'Declara la clave primaria (Primary Key) de la entidad. Permite a Hibernate identificar de forma unívoca a cada objeto en la sesión y en la caché de primer nivel.',
      sql: 'id BIGINT NOT NULL PRIMARY KEY',
      tip: 'Es la base del mapeo relacional. Hibernate no puede persistir una entidad que no tenga definida una propiedad @Id.'
    },
    'generated': {
      title: '@GeneratedValue(strategy = GenerationType.IDENTITY)',
      desc: 'Configura la estrategia de generación automática de la clave primaria. En MySQL, H2 o SQL Server delega en la columna auto-incremental de la base de datos.',
      sql: 'AUTO_INCREMENT (MySQL/H2) o GENERATED ALWAYS AS IDENTITY',
      tip: 'Para PostgreSQL u Oracle, la estrategia recomendada suele ser GenerationType.SEQUENCE.'
    },
    'column-nombre': {
      title: '@Column(name = "nombre", nullable = false, length = 100)',
      desc: 'Define las restricciones y características de la columna relacional: nombre de columna, si admite nulos (NOT NULL) y longitud máxima de caracteres (VARCHAR).',
      sql: 'nombre VARCHAR(100) NOT NULL',
      tip: 'Permite que Hibernate valide los datos antes de enviar la sentencia y genere un esquema DDL robusto y tipado.'
    },
    'column-precio': {
      title: '@Column(name = "precio", nullable = false)',
      desc: 'Mapea un atributo numérico tipo Double o BigDecimal a una columna de precisión decimal en la base de datos.',
      sql: 'precio DOUBLE PRECISION NOT NULL',
      tip: 'Para cálculos financieros o contables estrictos, se recomienda BigDecimal en lugar de Double.'
    },
    'column-cantidad': {
      title: '@Column(name = "cantidad")',
      desc: 'Mapea la propiedad de existencias numéricas. Al no especificar nullable, por defecto admite valores NULL a menos que se defina lo contrario.',
      sql: 'cantidad INT',
      tip: 'Si usas el tipo primitivo "int" en lugar de "Integer", no admitirá nulos y tendrá 0 por defecto.'
    },
    'transient': {
      title: '@Transient',
      desc: 'Indica a Hibernate que este atributo en Java NO DEBE guardarse ni mapearse a ninguna columna en la base de datos. Se utiliza para campos de cálculo temporal en memoria.',
      sql: '-- Sin columna en la base de datos (Ignorado por el ORM)',
      tip: 'Ideal para contraseñas sin encriptar en formularios, cálculos en tiempo de ejecución o estados de interfaz de usuario.'
    }
  };

  // Handle Annotation Clicks
  annotTags.forEach(tag => {
    tag.addEventListener('click', () => {
      annotTags.forEach(t => t.classList.remove('active'));
      tag.classList.add('active');

      const annotKey = tag.getAttribute('data-annot');
      const data = annotationsData[annotKey];
      if (data) {
        detailsDefaultState.classList.add('hidden');
        annotActiveCard.classList.remove('hidden');

        annotTitle.textContent = data.title;
        annotDesc.textContent = data.desc;
        annotSqlEffect.textContent = data.sql;
        annotTip.textContent = data.tip;
      }
    });
  });

  // ========================================================
  // 4. COMPARISON TABS (JDBC vs ORM)
  // ========================================================
  const comparisonCodes = {
    guardar: {
      jdbc: `// Requiere escribir SQL manual como String (propenso a errores tipográficos):
String sql = "INSERT INTO productos (nombre, precio, cantidad) VALUES (?, ?, ?)";
try (Connection conn = dataSource.getConnection();
     PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
    
    // Mapeo manual por posición (si cambias el orden, explota):
    ps.setString(1, producto.getNombre());
    ps.setDouble(2, producto.getPrecio());
    ps.setInt(3, producto.getCantidad());
    
    ps.executeUpdate();
    
    // Recuperación manual del ID autoincremental:
    try (ResultSet rs = ps.getGeneratedKeys()) {
        if (rs.next()) {
            producto.setId(rs.getLong(1));
        }
    }
} catch (SQLException e) {
    e.printStackTrace(); // Gestión engorrosa de excepciones
}`,
      orm: `// ¡Cero SQL a mano! Manipulación directa del objeto Java:
session.beginTransaction();

session.persist(producto); // Hibernate genera el INSERT y asigna el ID solo

session.getTransaction().commit();

// Ventajas inmediatas:
// 1. Tipado estricto por el compilador de Java.
// 2. Compatible con MySQL, PostgreSQL, Oracle o H2 sin cambiar código.
// 3. Hibernate gestiona la transacción y el ciclo de vida del objeto.`
    },
    consultar: {
      jdbc: `// Con JDBC tradicional: Escribir SELECT, recorrer cursor y mapear a mano
String sql = "SELECT id, nombre, precio, cantidad FROM productos";
List<Producto> lista = new ArrayList<>();

try (Connection conn = dataSource.getConnection();
     Statement stmt = conn.createStatement();
     ResultSet rs = stmt.executeQuery(sql)) {

    while (rs.next()) {
        // Conversión manual columna por columna:
        Producto p = new Producto();
        p.setId(rs.getLong("id"));
        p.setNombre(rs.getString("nombre"));
        p.setPrecio(rs.getDouble("precio"));
        p.setCantidad(rs.getInt("cantidad"));
        lista.add(p);
    }
} catch (SQLException e) {
    e.printStackTrace();
}`,
      orm: `// Con Hibernate: Una sola consulta orientada a entidades (HQL o Criteria)
List<Producto> lista = session
    .createQuery("from Producto", Producto.class)
    .list();

// Hibernate traduce 'from Producto' al dialecto específico, ejecuta
// el SELECT, instancia automáticamente cada objeto Producto y llena
// sus atributos con los datos devueltos por el motor relacional.`
    }
  };

  compTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      compTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      const mode = tab.getAttribute('data-tab');
      codeJdbc.textContent = comparisonCodes[mode].jdbc;
      codeOrm.textContent = comparisonCodes[mode].orm;
    });
  });

  // ========================================================
  // 5. PROJECT FILES (SOURCE CODE VIEWER)
  // ========================================================
  const projectFiles = {
    pom: {
      path: 'pom.xml',
      content: `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.sena.adso</groupId>
    <artifactId>hibernate-productos</artifactId>
    <version>1.0.0-SNAPSHOT</version>

    <properties>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <hibernate.version>6.4.4.Final</hibernate.version>
    </properties>

    <dependencies>
        <!-- 1. Hibernate ORM Core (Implementación JPA) -->
        <dependency>
            <groupId>org.hibernate.orm</groupId>
            <artifactId>hibernate-core</artifactId>
            <version>\${hibernate.version}</version>
        </dependency>

        <!-- 2. Jakarta Persistence API (Especificación estándar) -->
        <dependency>
            <groupId>jakarta.persistence</groupId>
            <artifactId>jakarta.persistence-api</artifactId>
            <version>3.1.0</version>
        </dependency>

        <!-- 3. Driver de Base de Datos MySQL 8 -->
        <dependency>
            <groupId>com.mysql</groupId>
            <artifactId>mysql-connector-j</artifactId>
            <version>8.3.0</version>
        </dependency>

        <!-- 4. Driver H2 (Para pruebas en memoria sin instalar nada) -->
        <dependency>
            <groupId>com.h2database</groupId>
            <artifactId>h2</artifactId>
            <version>2.2.224</version>
        </dependency>
    </dependencies>
</project>`
    },
    config: {
      path: 'src/main/resources/hibernate.cfg.xml',
      content: `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE hibernate-configuration PUBLIC
        "-//Hibernate/Hibernate Configuration DTD 3.0//EN"
        "http://www.hibernate.org/dtd/hibernate-configuration-3.0.dtd">

<hibernate-configuration>
    <session-factory>
        <!-- 1. Configuración de Conexión JDBC (Ejemplo MySQL) -->
        <property name="hibernate.connection.driver_class">com.mysql.cj.jdbc.Driver</property>
        <property name="hibernate.connection.url">jdbc:mysql://localhost:3306/tienda_sena?createDatabaseIfNotExist=true&amp;useSSL=false</property>
        <property name="hibernate.connection.username">root</property>
        <property name="hibernate.connection.password">admin123</property>

        <!-- 2. Dialecto SQL específico para MySQL 8 -->
        <property name="hibernate.dialect">org.hibernate.dialect.MySQLDialect</property>

        <!-- 3. MOSTRAR Y FORMATEAR EL SQL (Vital para la exposición) -->
        <property name="hibernate.show_sql">true</property>
        <property name="hibernate.format_sql">true</property>
        <property name="hibernate.highlight_sql">true</property>

        <!-- 4. EVOLUCIÓN AUTOMÁTICA DEL ESQUEMA DDL -->
        <!-- "update": Crea o altera tablas sin borrar los registros existentes -->
        <property name="hibernate.hbm2ddl.auto">update</property>

        <!-- 5. Registrar las entidades anotadas -->
        <mapping class="com.sena.adso.model.Producto"/>
    </session-factory>
</hibernate-configuration>`
    },
    entity: {
      path: 'src/main/java/com/sena/adso/model/Producto.java',
      content: `package com.sena.adso.model;

import jakarta.persistence.*;

/**
 * Entidad Producto mapeada con JPA y Hibernate.
 * Cumple con el estándar del Tema 8 (ADSO SENA).
 */
@Entity
@Table(name = "productos")
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nombre", nullable = false, length = 100)
    private String nombre;

    @Column(name = "precio", nullable = false)
    private Double precio;

    @Column(name = "cantidad")
    private Integer cantidad;

    // CAMPO DEL RETO DE EXPOSICIÓN ("Ahora háganlo ustedes"):
    @Column(name = "categoria", length = 80)
    private String categoria;

    // Constructor vacío obligatorio para JPA
    public Producto() {
    }

    // Constructor de conveniencia
    public Producto(String nombre, Double precio, Integer cantidad, String categoria) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
        this.categoria = categoria;
    }

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public Double getPrecio() { return precio; }
    public void setPrecio(Double precio) { this.precio = precio; }

    public Integer getCantidad() { return cantidad; }
    public void setCantidad(Integer cantidad) { this.cantidad = cantidad; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    @Override
    public String toString() {
        return "Producto{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", precio=" + precio +
                ", cantidad=" + cantidad +
                ", categoria='" + categoria + '\'' +
                '}';
    }
}`
    },
    util: {
      path: 'src/main/java/com/sena/adso/util/HibernateUtil.java',
      content: `package com.sena.adso.util;

import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

/**
 * Clase utilitaria para crear y administrar el SessionFactory único (Singleton).
 */
public class HibernateUtil {

    private static SessionFactory sessionFactory;

    static {
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // Lee hibernate.cfg.xml por defecto
                .build();
        try {
            sessionFactory = new MetadataSources(registry)
                    .buildMetadata()
                    .buildSessionFactory();
        } catch (Exception ex) {
            StandardServiceRegistryBuilder.destroy(registry);
            System.err.println("Fallo al iniciar SessionFactory: " + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void shutdown() {
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }
}`
    },
    main: {
      path: 'src/main/java/com/sena/adso/MainApp.java',
      content: `package com.sena.adso;

import com.sena.adso.model.Producto;
import com.sena.adso.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;

/**
 * Aplicación principal: Demostración en vivo de guardar y listar
 * SIN escribir una sola línea de SQL a mano.
 */
public class MainApp {

    public static void main(String[] args) {
        System.out.println("=== 1. GUARDAR PRODUCTO CON HIBERNATE ===");
        guardarProducto("Portátil Asus Zenbook", 4200000.0, 10, "Tecnología");

        System.out.println("\\n=== 2. LISTAR PRODUCTOS SIN SQL ===");
        listarProductos();

        // Cerrar recursos al finalizar
        HibernateUtil.shutdown();
    }

    public static void guardarProducto(String nombre, Double precio, Integer cantidad, String categoria) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();

            Producto p = new Producto(nombre, precio, cantidad, categoria);
            
            // Hibernate traduce esto a un INSERT con los parámetros enlazados:
            session.persist(p);

            tx.commit();
            System.out.println("✔ Producto guardado con ID asignado automáticamente: " + p.getId());
        }
    }

    public static void listarProductos() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // HQL (Hibernate Query Language): orientado a objetos, no a tablas físicas
            List<Producto> productos = session
                    .createQuery("from Producto", Producto.class)
                    .list();

            System.out.println("Total de productos en base de datos: " + productos.size());
            for (Producto p : productos) {
                System.out.println(" - " + p);
            }
        }
    }
}`
    }
  };

  // Render initial project file
  function renderProjectFile(fileKey) {
    const file = projectFiles[fileKey];
    if (file) {
      activeFilePath.textContent = file.path;
      fileViewerCode.textContent = file.content;
    }
  }
  renderProjectFile('pom');

  fileTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      fileTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const fileKey = tab.getAttribute('data-file');
      renderProjectFile(fileKey);
    });
  });

  btnCopyFileContent.addEventListener('click', () => {
    navigator.clipboard.writeText(fileViewerCode.textContent)
      .then(() => showToast('✔ Archivo copiado al portapapeles', 'success'))
      .catch(() => showToast('Error al copiar', 'warning'));
  });

  // ========================================================
  // 6. DATABASE TABLE & TERMINAL LOGIC
  // ========================================================
  function renderDatabaseTable(highlightId = null) {
    dbTableBody.innerHTML = '';
    
    // Update headers based on challenge state
    if (state.challengeActive) {
      tableHeaderRow.innerHTML = `
        <th>ID <span class="th-type">(BIGINT PK)</span></th>
        <th>NOMBRE <span class="th-type">(VARCHAR)</span></th>
        <th>PRECIO <span class="th-type">(DOUBLE)</span></th>
        <th>CANTIDAD <span class="th-type">(INT)</span></th>
        <th class="th-highlight">CATEGORÍA <span class="th-type">(VARCHAR)</span></th>
      `;
    } else {
      tableHeaderRow.innerHTML = `
        <th>ID <span class="th-type">(BIGINT PK)</span></th>
        <th>NOMBRE <span class="th-type">(VARCHAR)</span></th>
        <th>PRECIO <span class="th-type">(DOUBLE)</span></th>
        <th>CANTIDAD <span class="th-type">(INT)</span></th>
      `;
    }

    state.products.forEach(p => {
      const tr = document.createElement('tr');
      if (highlightId === p.id) {
        tr.classList.add('row-new');
      }

      const formattedPrice = new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(p.precio);

      if (state.challengeActive) {
        tr.innerHTML = `
          <td><strong>${p.id}</strong></td>
          <td>${p.nombre}</td>
          <td>${formattedPrice}</td>
          <td>${p.cantidad} u</td>
          <td><span class="badge-new">${p.categoria || 'Sin categoría'}</span></td>
        `;
      } else {
        tr.innerHTML = `
          <td><strong>${p.id}</strong></td>
          <td>${p.nombre}</td>
          <td>${formattedPrice}</td>
          <td>${p.cantidad} u</td>
        `;
      }
      dbTableBody.appendChild(tr);
    });

    dbRowCount.textContent = `${state.products.length} registros`;
  }

  function getTimestamp() {
    const now = new Date();
    return now.toTimeString().split(' ')[0] + '.' + String(now.getMilliseconds()).padStart(3, '0');
  }

  function appendTerminalLog(sqlQuery, binders = [], isDdl = false) {
    const logEntry = document.createElement('div');
    logEntry.classList.add('log-entry');

    let formattedSqlHtml = '';
    if (state.formatSql) {
      formattedSqlHtml = sqlQuery
        .replace(/\b(insert|into|values|select|from|update|set|where|delete|alter table|add column|create table|drop table)\b/gi, '<span class="sql-kw">$1</span>')
        .replace(/\b(productos|p1_0)\b/gi, '<span class="sql-table">$1</span>')
        .replace(/\?/g, '<span class="sql-param">?</span>');
    } else {
      formattedSqlHtml = sqlQuery;
    }

    let bindersHtml = '';
    if (binders.length > 0) {
      bindersHtml = binders.map(b => `
        <div class="log-binder">[TRACE] org.hibernate.type.descriptor.sql.BasicBinder - binding parameter [${b.index}] as [${b.type}] - '${b.val}'</div>
      `).join('');
    }

    logEntry.innerHTML = `
      <div class="log-meta">
        [${getTimestamp()}] <span class="badge-source">org.hibernate.SQL</span> :
      </div>
      <div class="log-sql">${formattedSqlHtml}</div>
      ${bindersHtml}
    `;

    terminalBody.appendChild(logEntry);
    terminalBody.scrollTop = terminalBody.scrollHeight;
  }

  // Initial welcome logs in terminal
  appendTerminalLog(`/* HIBERNATE INITIALIZATION (JPA 3.1) */
-- Dialect: org.hibernate.dialect.MySQLDialect
-- hibernate.hbm2ddl.auto = update
-- SessionFactory iniciado correctamente en memoria.`);

  renderDatabaseTable();

  // Dialect change
  selectDialect.addEventListener('change', (e) => {
    state.dialect = e.target.value;
    const names = {
      mysql: 'Dialecto: MySQL 8',
      h2: 'Dialecto: H2 In-Memory',
      postgres: 'Dialecto: PostgreSQL'
    };
    dialectBadge.textContent = names[state.dialect];
    appendTerminalLog(`/* Configuración modificada */
-- Dialecto activo cambiado a: ${names[state.dialect]}
-- Hibernate adaptará la sintaxis de generación de claves y tipos SQL.`);
    showToast(`Dialecto cambiado a ${names[state.dialect]}`, 'info');
  });

  chkFormatSql.addEventListener('change', (e) => {
    state.formatSql = e.target.checked;
  });

  // Action 1: Persist Product
  btnPersist.addEventListener('click', () => {
    const nombre = inputNombre.value.trim();
    const precio = parseFloat(inputPrecio.value) || 0;
    const cantidad = parseInt(inputCantidad.value) || 1;
    const categoria = state.challengeActive ? (inputCategoria.value.trim() || 'General') : null;

    if (!nombre) {
      showToast('Por favor escribe el nombre del producto', 'warning');
      return;
    }

    const newProd = {
      id: state.nextId++,
      nombre,
      precio,
      cantidad,
      categoria
    };

    state.products.push(newProd);

    // Hibernate Generated SQL (Formatted)
    let sql = '';
    let binders = [];

    if (state.challengeActive) {
      sql = `Hibernate:
    insert
    into
        productos
        (categoria, cantidad, nombre, precio)
    values
        (?, ?, ?, ?)`;

      binders = [
        { index: 1, type: 'VARCHAR', val: newProd.categoria },
        { index: 2, type: 'INTEGER', val: newProd.cantidad },
        { index: 3, type: 'VARCHAR', val: newProd.nombre },
        { index: 4, type: 'DOUBLE', val: newProd.precio }
      ];
    } else {
      sql = `Hibernate:
    insert
    into
        productos
        (cantidad, nombre, precio)
    values
        (?, ?, ?)`;

      binders = [
        { index: 1, type: 'INTEGER', val: newProd.cantidad },
        { index: 2, type: 'VARCHAR', val: newProd.nombre },
        { index: 3, type: 'DOUBLE', val: newProd.precio }
      ];
    }

    appendTerminalLog(sql, binders);
    renderDatabaseTable(newProd.id);

    showToast(`✔ session.persist() ejecutado: Producto #${newProd.id} guardado en BD`, 'success');
  });

  // Action 2: Find All (Query)
  btnFindAll.addEventListener('click', () => {
    let sql = '';
    if (state.challengeActive) {
      sql = `Hibernate:
    select
        p1_0.id,
        p1_0.categoria,
        p1_0.cantidad,
        p1_0.nombre,
        p1_0.precio
    from
        productos p1_0`;
    } else {
      sql = `Hibernate:
    select
        p1_0.id,
        p1_0.cantidad,
        p1_0.nombre,
        p1_0.precio
    from
        productos p1_0`;
    }

    appendTerminalLog(sql, []);
    renderDatabaseTable();
    showToast(`✔ session.createQuery("from Producto") devolvió ${state.products.length} entidades`, 'info');
  });

  // Action 3: Dirty Checking (Automatic update)
  btnDirtyChecking.addEventListener('click', () => {
    if (state.products.length === 0) {
      showToast('No hay productos en la tabla para actualizar', 'warning');
      return;
    }

    const targetProduct = state.products[0];
    const oldPrice = targetProduct.precio;
    targetProduct.precio = Math.round(targetProduct.precio * 0.9); // 10% discount

    const sql = `Hibernate:
    update
        productos
    set
        precio=?
    where
        id=?`;

    const binders = [
      { index: 1, type: 'DOUBLE', val: targetProduct.precio },
      { index: 2, type: 'BIGINT', val: targetProduct.id }
    ];

    appendTerminalLog(sql, binders);
    renderDatabaseTable(targetProduct.id);

    showToast(`✔ Dirty Checking: Hibernate detectó cambio de $${oldPrice} a $${targetProduct.precio} y generó UPDATE automático`, 'success');
  });

  // Action 4: Remove Product
  btnDelete.addEventListener('click', () => {
    if (state.products.length === 0) {
      showToast('La tabla ya está vacía', 'warning');
      return;
    }

    const removed = state.products.pop();

    const sql = `Hibernate:
    delete
    from
        productos
    where
        id=?`;

    const binders = [
      { index: 1, type: 'BIGINT', val: removed.id }
    ];

    appendTerminalLog(sql, binders);
    renderDatabaseTable();

    showToast(`✔ session.remove(producto): Producto #${removed.id} eliminado`, 'warning');
  });

  // Clear Terminal
  btnClearConsole.addEventListener('click', () => {
    terminalBody.innerHTML = '';
    appendTerminalLog(`/* Terminal reiniciada */
-- Esperando operaciones de Session o EntityManager.`);
  });

  // Copy SQL for Deliverable
  btnCopySql.addEventListener('click', () => {
    const logs = terminalBody.innerText;
    navigator.clipboard.writeText(logs)
      .then(() => showToast('📋 Captura de SQL copiada (Cumple el Entregable 2)', 'success'))
      .catch(() => showToast('Error al copiar al portapapeles', 'warning'));
  });

  // ========================================================
  // 7. RETO PRÁCTICO "AHORA HÁGANLO USTEDES" (6 MINUTOS)
  // ========================================================
  btnActivateChallenge.addEventListener('click', () => {
    if (!state.challengeActive) {
      state.challengeActive = true;
      groupCategoria.style.display = 'block';
      btnResetChallenge.style.display = 'inline-block';
      btnChallengeText.textContent = '✔ Reto Activo: Campo "categoría" mapeado con éxito';
      btnActivateChallenge.style.background = '#10B981';

      diffBadge.textContent = '+1 Campo Agregado';
      diffBadge.classList.add('active');

      retoCodeSnippet.innerHTML = `// ¡CAMPO AGREGADO CON ÉXITO!
@Entity
@Table(name = "productos")
public class Producto {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private Double precio;
    private Integer cantidad;

    <span style="color: #34D399; font-weight: bold; background: rgba(16,185,129,0.15); padding: 2px 6px; border-radius: 4px;">// NUEVO CAMPO AÑADIDO POR LOS COMPAÑEROS:
    @Column(name = "categoria", length = 80)
    private String categoria;</span>

    // Getter y Setter
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
}`;

      // Simulate Hibernate hbm2ddl.auto = update ALTER TABLE
      const ddlSql = `Hibernate:
    alter table if exists productos
       add column categoria varchar(80)`;

      appendTerminalLog(ddlSql, [], true);
      renderDatabaseTable();

      showToast('🚀 ¡Evolución de esquema! Hibernate ejecutó "ALTER TABLE productos ADD COLUMN categoria"', 'success');

      // Scroll smoothly to simulator to see the new column and form field
      const labElem = document.getElementById('laboratorio');
      if (labElem) {
        labElem.scrollIntoView({ behavior: 'smooth' });
      }
    }
  });

  btnResetChallenge.addEventListener('click', () => {
    state.challengeActive = false;
    groupCategoria.style.display = 'none';
    btnResetChallenge.style.display = 'none';
    btnChallengeText.textContent = '¡Ejecutar Reto: Agregar Campo \'categoría\' a la Entidad!';
    btnActivateChallenge.style.background = '';
    diffBadge.textContent = 'Sin cambios';
    diffBadge.classList.remove('active');

    retoCodeSnippet.innerHTML = `// Estado actual de la entidad:
@Entity
@Table(name = "productos")
public class Producto {
    @Id @GeneratedValue
    private Long id;
    private String nombre;
    private Double precio;
    private Integer cantidad;

    // Haz clic en el botón para agregar 'categoria' aquí ➔
}`;

    appendTerminalLog(`/* Esquema revertido a 4 columnas originales */`);
    renderDatabaseTable();
    showToast('Entidad revertida al estado base', 'info');
  });

  // ========================================================
  // 8. OFFICIAL 20-MINUTE PRESENTATION COUNTDOWN TIMER
  // ========================================================
  const phases = [
    { start: 0, end: 3 * 60, name: '1. Introducción al tema (3 min)', selector: '.phase-1' },
    { start: 3 * 60, end: 11 * 60, name: '2. Demostración en vivo (8 min)', selector: '.phase-2' },
    { start: 11 * 60, end: 17 * 60, name: '3. "Ahora háganlo ustedes" (6 min)', selector: '.phase-3' },
    { start: 17 * 60, end: 20 * 60, name: '4. Preguntas y cierre (3 min)', selector: '.phase-4' }
  ];

  function updateTimerDisplay() {
    const total = state.timer.totalSeconds;
    const remaining = state.timer.currentSeconds;
    const elapsed = total - remaining;

    const m = Math.floor(remaining / 60);
    const s = remaining % 60;
    const timeFormatted = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;

    bigTimerDisplay.textContent = timeFormatted;
    navTimerDisplay.textContent = timeFormatted;

    // Identify current phase
    let activePhase = phases[0];
    for (let p of phases) {
      if (elapsed >= p.start && elapsed < p.end) {
        activePhase = p;
        break;
      }
    }
    if (elapsed >= total) {
      activePhase = { name: '¡Tiempo de exposición completado!', selector: '.phase-4' };
    }

    currentPhasePill.innerHTML = `Fase actual: <strong>${activePhase.name}</strong>`;

    // Highlight timeline items
    document.querySelectorAll('.timeline-item').forEach(item => item.classList.remove('active'));
    const activeTimelineItem = document.querySelector(activePhase.selector);
    if (activeTimelineItem) {
      activeTimelineItem.classList.add('active');
    }
  }

  function startTimer() {
    if (state.timer.isRunning) return;
    state.timer.isRunning = true;
    btnStartTimer.textContent = 'En marcha...';
    btnStartTimer.style.opacity = '0.7';

    state.timer.intervalId = setInterval(() => {
      if (state.timer.currentSeconds > 0) {
        state.timer.currentSeconds--;
        updateTimerDisplay();
      } else {
        clearInterval(state.timer.intervalId);
        state.timer.isRunning = false;
        showToast('⏰ ¡Fin del tiempo de exposición (20 min)!', 'warning');
      }
    }, 1000);
  }

  function pauseTimer() {
    if (!state.timer.isRunning) return;
    clearInterval(state.timer.intervalId);
    state.timer.isRunning = false;
    btnStartTimer.textContent = 'Reanudar';
    btnStartTimer.style.opacity = '1';
    showToast('Cronómetro pausado', 'info');
  }

  function resetTimer() {
    clearInterval(state.timer.intervalId);
    state.timer.isRunning = false;
    state.timer.currentSeconds = state.timer.totalSeconds;
    btnStartTimer.textContent = 'Iniciar';
    btnStartTimer.style.opacity = '1';
    updateTimerDisplay();
    showToast('Cronómetro reiniciado a 20:00', 'info');
  }

  btnStartTimer.addEventListener('click', startTimer);
  btnPauseTimer.addEventListener('click', pauseTimer);
  btnResetTimer.addEventListener('click', resetTimer);

  btnTimerToggle.addEventListener('click', () => {
    const expoElem = document.getElementById('exposicion');
    if (expoElem) {
      expoElem.scrollIntoView({ behavior: 'smooth' });
    }
  });

  updateTimerDisplay();

  // ========================================================
  // 9. TOAST NOTIFICATION HELPER
  // ========================================================
  const toastContainer = document.getElementById('toastContainer');

  function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    let icon = 'ℹ️';
    if (type === 'success') icon = '✔';
    if (type === 'warning') icon = '⚠️';

    toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
    toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }

  // ========================================================
  // 10. SMOOTH SCROLL NAVBAR HIGHLIGHT
  // ========================================================
  const navLinks = document.querySelectorAll('.nav-link');
  window.addEventListener('scroll', () => {
    let current = '';
    const sections = document.querySelectorAll('section');
    sections.forEach(section => {
      const sectionTop = section.offsetTop - 120;
      if (window.scrollY >= sectionTop) {
        current = section.getAttribute('id');
      }
    });

    navLinks.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === `#${current}`) {
        link.classList.add('active');
      }
    });
  });

});
